package com.example.emilyhowing.secondconscience;

/**
 * Created by emilyhowing on 4/2/18.
 */

public interface AsyncResponse {
    void processFinish(String output);
}
